# DrinkMark Mailing System

A complete mailing system for the DrinkMark.in custom water bottle website, featuring automated email responses and professional email templates.

## Features

- ✅ **Automated Email System** - Sends emails to both customers and team
- ✅ **Professional Email Templates** - Beautiful HTML emails with DrinkMark branding
- ✅ **Form Validation** - Server-side validation for all form fields
- ✅ **Real-time Feedback** - Loading states and success/error messages
- ✅ **Responsive Design** - Works on all devices
- ✅ **Security** - Environment-based configuration for sensitive data

## Email Templates

### 1. Team Notification Email
- Sent to DrinkMark team when form is submitted
- Contains all customer details and project requirements
- Professional formatting with company branding

### 2. Customer Confirmation Email
- Sent to customer as confirmation
- Includes project summary and next steps
- Professional DrinkMark branding and contact information

## Setup Instructions

### Prerequisites
- Node.js (version 14 or higher)
- Gmail account with App Password enabled
- npm or yarn package manager

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Email Settings
1. Copy `env.example` to `.env`:
```bash
cp env.example .env
```

2. Edit `.env` file with your Gmail credentials:
```env
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password
PORT=3000
```

**Important:** For Gmail, you need to use an App Password, not your regular password:
1. Enable 2-Factor Authentication on your Google account
2. Go to Google Account settings > Security > App passwords
3. Generate a new app password for "Mail"
4. Use that password in EMAIL_PASS

### 3. Start the Server
```bash
# Development mode (with auto-restart)
npm run dev

# Production mode
npm start
```

The server will start on `http://localhost:3000`

## API Endpoints

### POST `/api/contact`
Handles contact form submissions and sends emails.

**Request Body:**
```json
{
  "name": "Company Name",
  "email": "contact@company.com",
  "phone": "+1234567890",
  "quantity": "1000 bottles",
  "service": "Corporate Branded",
  "message": "Project details..."
}
```

**Response:**
```json
{
  "success": true,
  "message": "Thank you! We'll send you a detailed manufacturing quote within 24 hours."
}
```

### GET `/api/health`
Health check endpoint to verify server status.

## File Structure

```
Drink-mark/
├── server.js              # Main Express server
├── package.json           # Node.js dependencies
├── env.example            # Environment configuration template
├── index.html             # Main website HTML
├── style.css              # Website styling
├── script.js              # Frontend JavaScript (updated)
├── README.md              # This file
└── .git/                  # Git repository
```

## How It Works

1. **User submits form** on the DrinkMark website
2. **Frontend validation** ensures all required fields are filled
3. **Form data sent** to `/api/contact` endpoint
4. **Server validates** data and sends two emails:
   - Team notification with customer details
   - Customer confirmation with project summary
5. **User receives** immediate feedback and confirmation email
6. **Team receives** detailed inquiry for follow-up

## Customization

### Email Templates
Edit the email templates in `server.js`:
- `createCustomerEmailTemplate()` - Team notification email
- `createCustomerConfirmationTemplate()` - Customer confirmation email

### Styling
- Email templates use inline CSS for maximum compatibility
- Colors match DrinkMark brand (#00d4ff, #0099cc)
- Responsive design for mobile email clients

### Form Fields
Add or modify form fields by updating:
1. HTML form in `index.html`
2. Form handling in `script.js`
3. Server validation in `server.js`
4. Email templates in `server.js`

## Troubleshooting

### Common Issues

**Email not sending:**
- Check Gmail App Password is correct
- Verify 2-Factor Authentication is enabled
- Check `.env` file exists and has correct values

**Server won't start:**
- Ensure Node.js is installed (version 14+)
- Check if port 3000 is available
- Verify all dependencies are installed

**Form submission errors:**
- Check browser console for JavaScript errors
- Verify server is running on correct port
- Check network tab for API call failures

### Debug Mode
Enable detailed logging by adding to `.env`:
```env
DEBUG=true
NODE_ENV=development
```

## Security Considerations

- ✅ Environment variables for sensitive data
- ✅ Input validation and sanitization
- ✅ CORS configuration for cross-origin requests
- ✅ Rate limiting (can be added for production)
- ✅ HTTPS recommended for production

## Production Deployment

1. **Environment Variables**: Set production values in your hosting platform
2. **HTTPS**: Enable SSL/TLS for secure email transmission
3. **Domain**: Update CORS settings for your production domain
4. **Monitoring**: Add logging and monitoring for production use
5. **Backup**: Regular backups of email logs and configurations

## Support

For technical support or questions about the mailing system:
- Email: drinkmark.official@gmail.com
- Phone: 8797496373

## License

MIT License - Feel free to modify and use for your projects.
