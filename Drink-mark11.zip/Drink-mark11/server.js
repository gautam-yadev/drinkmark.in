const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('.'));

// Email configuration
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER = 'drinkmark.official@gmail.com',
    pass: process.env.EMAIL_PASS = 'kisg eeaz wugw auxf'
  }
});

// Email template for customer inquiries
const createCustomerEmailTemplate = (formData) => {
  return `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9;">
      <div style="background: linear-gradient(135deg, #00d4ff, #0099cc); padding: 20px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="color: white; margin: 0; font-size: 28px;">DrinkMark.in</h1>
        <p style="color: white; margin: 10px 0 0 0; font-size: 16px;">Premium Water Customization</p>
      </div>
      
      <div style="background: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
        <h2 style="color: #333; margin-bottom: 20px;">New Custom Water Bottle Inquiry</h2>
        
        <div style="margin-bottom: 20px;">
          <h3 style="color: #00d4ff; margin-bottom: 10px;">Contact Information</h3>
          <p><strong>Company/Name:</strong> ${formData.name}</p>
          <p><strong>Email:</strong> ${formData.email}</p>
          <p><strong>Phone:</strong> ${formData.phone || 'Not provided'}</p>
        </div>
        
        <div style="margin-bottom: 20px;">
          <h3 style="color: #00d4ff; margin-bottom: 10px;">Project Details</h3>
          <p><strong>Estimated Quantity:</strong> ${formData.quantity}</p>
          <p><strong>Product Interest:</strong> ${formData.service}</p>
          <p><strong>Project Details:</strong></p>
          <p style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; border-left: 4px solid #00d4ff;">${formData.message}</p>
        </div>
        
        <div style="background-color: #e8f4fd; padding: 20px; border-radius: 8px; border-left: 4px solid #00d4ff;">
          <p style="margin: 0; color: #333; font-size: 14px;">
            <strong>Next Steps:</strong> Our team will review your requirements and send you a detailed manufacturing quote within 24 hours. 
            We'll also schedule a consultation call to discuss your project in detail.
          </p>
        </div>
        
        <div style="margin-top: 30px; text-align: center; padding-top: 20px; border-top: 1px solid #eee;">
          <p style="color: #666; font-size: 12px;">
            This inquiry was submitted from the DrinkMark.in website contact form.
          </p>
        </div>
      </div>
    </div>
  `;
};

// Email template for customer confirmation
const createCustomerConfirmationTemplate = (formData) => {
  return `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9;">
      <div style="background: linear-gradient(135deg, #00d4ff, #0099cc); padding: 20px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="color: white; margin: 0; font-size: 28px;">DrinkMark.in</h1>
        <p style="color: white; margin: 10px 0 0 0; font-size: 16px;">Premium Water Customization</p>
      </div>
      
      <div style="background: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
        <h2 style="color: #333; margin-bottom: 20px;">Thank You for Your Inquiry!</h2>
        
        <p style="color: #555; line-height: 1.6; margin-bottom: 20px;">
          Dear ${formData.name},
        </p>
        
        <p style="color: #555; line-height: 1.6; margin-bottom: 20px;">
          Thank you for reaching out to DrinkMark.in regarding your custom water bottle project. 
          We're excited to help you create the perfect branded water solution for your business.
        </p>
        
        <div style="background-color: #e8f4fd; padding: 20px; border-radius: 8px; border-left: 4px solid #00d4ff; margin-bottom: 20px;">
          <h3 style="color: #00d4ff; margin-top: 0;">What Happens Next?</h3>
          <ul style="color: #555; line-height: 1.6;">
            <li>Our team will review your requirements within 24 hours</li>
            <li>You'll receive a detailed manufacturing quote</li>
            <li>We'll schedule a consultation call to discuss your project</li>
            <li>Custom design and formulation process begins</li>
          </ul>
        </div>
        
        <div style="background-color: #f0f8ff; padding: 20px; border-radius: 8px; border-left: 4px solid #0099cc;">
          <h3 style="color: #0099cc; margin-top: 0;">Project Summary</h3>
          <p><strong>Product Interest:</strong> ${formData.service}</p>
          <p><strong>Estimated Quantity:</strong> ${formData.quantity}</p>
          <p><strong>Project Details:</strong> ${formData.message.substring(0, 100)}${formData.message.length > 100 ? '...' : ''}</p>
        </div>
        
        <div style="margin-top: 30px; text-align: center;">
          <p style="color: #666; font-size: 14px;">
            If you have any immediate questions, feel free to contact us at:
          </p>
          <p style="color: #00d4ff; font-size: 16px; font-weight: bold;">
            drinkmark.official@gmail.com | 8797496373
          </p>
        </div>
        
        <div style="margin-top: 30px; text-align: center; padding-top: 20px; border-top: 1px solid #eee;">
          <p style="color: #666; font-size: 12px;">
            &copy; 2025 DrinkMark. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  `;
};

// API endpoint for handling contact form submissions
app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, phone, quantity, service, message } = req.body;
    
    // Validation
    if (!name || !email || !quantity || !service || !message) {
      return res.status(400).json({ 
        success: false, 
        message: 'All required fields must be filled' 
      });
    }
    
    // Email to DrinkMark team
    const teamMailOptions = {
      from: process.env.EMAIL_USER || 'drinkmark.official@gmail.com',
      to: 'drinkmark.official@gmail.com',
      subject: `New Custom Water Bottle Inquiry - ${name}`,
      html: createCustomerEmailTemplate(req.body)
    };
    
    // Email to customer (confirmation)
    const customerMailOptions = {
      from: process.env.EMAIL_USER || 'drinkmark.official@gmail.com',
      to: email,
      subject: 'Thank You for Your DrinkMark Inquiry',
      html: createCustomerConfirmationTemplate(req.body)
    };
    
    // Send emails
    await transporter.sendMail(teamMailOptions);
    await transporter.sendMail(customerMailOptions);
    
    // Log the inquiry
    console.log(`New inquiry received from ${name} (${email}) for ${service}`);
    
    res.json({ 
      success: true, 
      message: 'Thank you! We\'ll send you a detailed manufacturing quote within 24 hours.' 
    });
    
  } catch (error) {
    console.error('Email sending error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Sorry, there was an error sending your message. Please try again or contact us directly.' 
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'DrinkMark mailing system is running' });
});

// Serve the main HTML file
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 DrinkMark mailing system running on port ${PORT}`);
  console.log(`📧 Email configured for: ${process.env.EMAIL_USER || 'drinkmark.official@gmail.com'}`);
  console.log(`🌐 Server: http://localhost:${PORT}`);
});

module.exports = app;
