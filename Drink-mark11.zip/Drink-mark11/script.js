

      // Initialize GSAP and register plugins
      gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

      // --- GLOBAL ANIMATIONS ---

      // Page load animations for Hero Section
      gsap
        .timeline()
        .to(".hero h1", { opacity: 1, y: 0, duration: 1.2, ease: "power3.out" })
        .to(
          ".hero p",
          { opacity: 1, y: 0, duration: 1, ease: "power3.out" },
          "-=0.6"
        )
        .to(
          ".cta-button",
          { opacity: 1, y: 0, duration: 0.8, ease: "power3.out" },
          "-=0.4"
        );

      // Enhanced floating animation for water drops
      gsap.utils.toArray(".water-drop").forEach((drop, i) => {
        gsap.to(drop, {
          y: "random(-60, 60)",
          x: "random(-40, 40)",
          scale: "random(0.7, 1.3)",
          opacity: "random(0.3, 0.8)",
          duration: "random(4, 8)",
          ease: "sine.inOut",
          yoyo: true,
          repeat: -1,
          delay: i * 0.5,
        });
      });

      // Parallax effect for hero section
      gsap.to(".hero-content", {
        yPercent: -50,
        ease: "none",
        scrollTrigger: {
          trigger: ".hero",
          start: "top top",
          end: "bottom top",
          scrub: true,
        },
      });

      // Navbar background on scroll
      ScrollTrigger.create({
        start: "top -80",
        end: 99999,
        toggleClass: { className: "scrolled", targets: "nav" },
      });

      // --- SCROLL-TRIGGERED ANIMATIONS ---

      // Animate elements in as they enter the viewport
      const animateOnScroll = (selector, props) => {
        gsap.utils.toArray(selector).forEach((elem, i) => {
          gsap.to(elem, {
            ...props,
            scrollTrigger: {
              trigger: elem,
              start: "top 85%",
              toggleActions: "play none none reverse",
            },
          });
        });
      };

      animateOnScroll(".bottle-sample", {
        opacity: 1,
        y: 0,
        rotateY: 0,
        duration: 1,
        ease: "back.out(1.2)",
        stagger: 0.1,
      });
      animateOnScroll(".service-card", {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: "power3.out",
        stagger: 0.1,
      });
      animateOnScroll(".step", {
        opacity: 1,
        x: 0,
        duration: 0.8,
        ease: "power3.out",
        stagger: 0.2,
      });
      animateOnScroll(".about-text", {
        opacity: 1,
        x: 0,
        duration: 1,
        ease: "power3.out",
      });
      animateOnScroll(".about-stats", {
        opacity: 1,
        x: 0,
        duration: 1,
        ease: "power3.out",
        delay: 0.3,
      });
      animateOnScroll(".contact-form", {
        opacity: 1,
        y: 0,
        duration: 1,
        ease: "power3.out",
      });

      // Counter animation for stats
      gsap.utils.toArray(".stat-number").forEach((counter) => {
        const target = counter.textContent;
        const isPercentage = target.includes("%");
        const isPlus = target.includes("+");
        const isK = target.includes("K");

        let endValue = parseFloat(target.replace(/[^0-9.]/g, ""));
        if (isK) endValue *= 1000;

        gsap.from(counter, {
          textContent: 0,
          duration: 2.5,
          ease: "power3.out",
          snap: { textContent: 1 },
          scrollTrigger: {
            trigger: counter,
            start: "top 85%",
            toggleActions: "play none none reverse",
          },
          onUpdate: function () {
            let num = Math.ceil(this.targets()[0].textContent);
            if (isK) {
              counter.textContent =
                Math.floor(num / 1000) + "K" + (isPlus ? "+" : "");
            } else {
              counter.textContent =
                num + (isPercentage ? "%" : "") + (isPlus && !isK ? "+" : "");
            }
          },
        });
      });

      // --- EVENT LISTENERS & INTERACTIONS ---

      // Enhanced bottle sample hover effects for CSS bottles
      gsap.utils.toArray(".bottle-sample").forEach((sample) => {
        const visual = sample.querySelector(".bottle-visual");
        const features = sample.querySelectorAll(".bottle-features li");

        sample.addEventListener("mouseenter", () => {
          gsap.to(visual, {
            rotateY: 10,
            rotateX: 5,
            scale: 1.05,
            duration: 0.4,
            ease: "back.out(1.7)",
          });
          gsap.fromTo(
            features,
            { x: -10, opacity: 0.7 },
            {
              x: 0,
              opacity: 1,
              duration: 0.3,
              stagger: 0.05,
              ease: "power2.out",
            }
          );
        });

        sample.addEventListener("mouseleave", () => {
          gsap.to(visual, {
            rotateY: 0,
            rotateX: 0,
            scale: 1,
            duration: 0.4,
            ease: "power2.out",
          });
          // Note: The features animation is not reversed on leave to maintain visibility.
        });
      });

      // Service card hover effects
      gsap.utils.toArray(".service-card").forEach((card) => {
        const icon = card.querySelector(".service-icon");
        card.addEventListener("mouseenter", () => {
          gsap.to(icon, {
            scale: 1.2,
            rotation: 15,
            duration: 0.5,
            ease: "back.out(1.7)",
          });
        });
        card.addEventListener("mouseleave", () => {
          gsap.to(icon, {
            scale: 1,
            rotation: 0,
            duration: 0.5,
            ease: "back.out(1.7)",
          });
        });
      });

      // Smooth scrolling for all anchor links
      document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
        anchor.addEventListener("click", function (e) {
          e.preventDefault();
          const targetId = this.getAttribute("href");
          gsap.to(window, {
            duration: 1.5,
            scrollTo: { y: targetId, offsetY: 80 },
            ease: "power3.inOut",
          });
        });
      });

      // Order button click scrolls to contact form
      gsap.utils.toArray(".order-btn").forEach((btn) => {
        btn.addEventListener("click", function (e) {
          e.preventDefault();
          gsap.to(window, {
            duration: 1.5,
            scrollTo: { y: "#contact", offsetY: 80 },
            ease: "power3.inOut",
          });
        });
      });

      // Form submission handling with mailing system
      document
        .querySelector(".contact-form")
        .addEventListener("submit", async function (e) {
          e.preventDefault();
          
          // Get form data
          const formData = new FormData(this);
          const data = {
            name: formData.get('name'),
            email: formData.get('email'),
            phone: formData.get('phone'),
            quantity: formData.get('quantity'),
            service: formData.get('service'),
            message: formData.get('message')
          };
          
          // Show loading state
          const submitBtn = this.querySelector('.submit-btn');
          const originalText = submitBtn.textContent;
          submitBtn.textContent = 'Sending...';
          submitBtn.disabled = true;
          
          try {
            // Send to mailing system
            const response = await fetch('/api/contact', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (result.success) {
              // Success message
              const successMsg = document.createElement("div");
              successMsg.innerHTML = `
                <div style="background: rgba(0, 212, 255, 0.1); border: 2px solid #00d4ff; border-radius: 15px; padding: 20px; margin-top: 20px; text-align: center;">
                  <h3 style="color: #00d4ff; margin-bottom: 10px;">✅ Message Sent Successfully!</h3>
                  <p style="color: #00d4ff; font-size: 1.1rem; margin-bottom: 10px;">${result.message}</p>
                  <p style="color: #cccccc; font-size: 0.9rem;">Check your email for confirmation and next steps.</p>
                </div>
              `;

              this.parentNode.insertBefore(successMsg, this.nextSibling);
              gsap.from(successMsg, {
                opacity: 0,
                y: 20,
                duration: 0.8,
                ease: "power3.out",
              });

              this.reset();

              // Remove success message after 8 seconds
              setTimeout(() => {
                gsap.to(successMsg, {
                  opacity: 0,
                  y: -20,
                  duration: 0.5,
                  ease: "power3.in",
                  onComplete: () => successMsg.remove(),
                });
              }, 8000);
              
            } else {
              throw new Error(result.message || 'Failed to send message');
            }
            
          } catch (error) {
            console.error('Form submission error:', error);
            
            // Error message
            const errorMsg = document.createElement("div");
            errorMsg.innerHTML = `
              <div style="background: rgba(255, 0, 0, 0.1); border: 2px solid #ff4444; border-radius: 15px; padding: 20px; margin-top: 20px; text-align: center;">
                <h3 style="color: #ff4444; margin-bottom: 10px;">❌ Error Sending Message</h3>
                <p style="color: #ff4444; font-size: 1.1rem; margin-bottom: 10px;">${error.message || 'Please try again or contact us directly.'}</p>
                <p style="color: #cccccc; font-size: 0.9rem;">Email: drinkmark.official@gmail.com | Phone: 8797496373</p>
              </div>
            `;

            this.parentNode.insertBefore(errorMsg, this.nextSibling);
            gsap.from(errorMsg, {
              opacity: 0,
              y: 20,
              duration: 0.8,
              ease: "power3.out",
            });

            // Remove error message after 8 seconds
            setTimeout(() => {
              gsap.to(errorMsg, {
                opacity: 0,
                y: -20,
                duration: 0.5,
                ease: "power3.in",
                onComplete: () => errorMsg.remove(),
              });
            }, 8000);
          } finally {
            // Reset button state
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
          }
        });
   