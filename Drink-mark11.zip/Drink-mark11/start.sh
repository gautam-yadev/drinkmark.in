#!/bin/bash

echo "========================================"
echo "    DrinkMark Mailing System"
echo "========================================"
echo ""
echo "Starting the mailing system..."
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js is not installed!"
    echo "Please install Node.js from https://nodejs.org/"
    echo ""
    exit 1
fi

# Check if dependencies are installed
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
    if [ $? -ne 0 ]; then
        echo "ERROR: Failed to install dependencies!"
        exit 1
    fi
    echo ""
fi

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "WARNING: .env file not found!"
    echo "Please copy env.example to .env and configure your email settings."
    echo ""
    echo "Creating .env file from template..."
    cp env.example .env
    echo ""
    echo "Please edit .env file with your Gmail credentials before starting."
    echo ""
    read -p "Press Enter to continue after editing .env file..."
fi

echo "Starting server on http://localhost:3000"
echo "Press Ctrl+C to stop the server"
echo ""
npm start
