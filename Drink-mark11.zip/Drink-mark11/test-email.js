// Test script for DrinkMark mailing system
// Run this to test email functionality without the full website

const nodemailer = require('nodemailer');
require('dotenv').config();

// Test email configuration
const testTransporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER || 'drinkmark.official@gmail.com',
    pass: process.env.EMAIL_PASS || 'ilsn saom mujw wnzl',
  }
});

// Test email template
const testEmailTemplate = `
  <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9;">
    <div style="background: linear-gradient(135deg, #00d4ff, #0099cc); padding: 20px; text-align: center; border-radius: 10px 10px 0 0;">
      <h1 style="color: white; margin: 0; font-size: 28px;">DrinkMark.in</h1>
      <p style="color: white; margin: 10px 0 0 0; font-size: 16px;">Premium Water Customization</p>
    </div>
    
    <div style="background: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
      <h2 style="color: #333; margin-bottom: 20px;">🧪 Test Email - Mailing System Working!</h2>
      
      <p style="color: #555; line-height: 1.6; margin-bottom: 20px;">
        This is a test email to verify that the DrinkMark mailing system is working correctly.
      </p>
      
      <div style="background-color: #e8f4fd; padding: 20px; border-radius: 8px; border-left: 4px solid #00d4ff;">
        <h3 style="color: #00d4ff; margin-top: 0;">✅ Test Results</h3>
        <ul style="color: #555; line-height: 1.6;">
          <li>Email server connection: SUCCESS</li>
          <li>Email template rendering: SUCCESS</li>
          <li>Email delivery: SUCCESS</li>
          <li>Mailing system: READY FOR PRODUCTION</li>
        </ul>
      </div>
      
      <div style="margin-top: 30px; text-align: center; padding-top: 20px; border-top: 1px solid #eee;">
        <p style="color: #666; font-size: 12px;">
          Test completed at: ${new Date().toLocaleString()}
        </p>
      </div>
    </div>
  </div>
`;

// Test function
async function testEmailSystem() {
  console.log('🧪 Testing DrinkMark Mailing System...\n');
  
  try {
    // Verify environment variables
    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
      console.log('❌ Environment variables not set!');
      console.log('Please create a .env file with EMAIL_USER and EMAIL_PASS');
      console.log('Copy env.example to .env and fill in your Gmail credentials\n');
      return;
    }
    
    console.log('📧 Email Configuration:');
    console.log(`   User: ${process.env.EMAIL_USER}`);
    console.log(`   Pass: ${process.env.EMAIL_PASS ? '***SET***' : 'NOT SET'}`);
    console.log('');
    
    // Test email connection
    console.log('🔌 Testing email connection...');
    await testTransporter.verify();
    console.log('✅ Email connection successful!\n');
    
    // Send test email
    console.log('📤 Sending test email...');
    const testMailOptions = {
      from: process.env.EMAIL_USER,
      to: process.env.EMAIL_USER, // Send to yourself for testing
      subject: '🧪 DrinkMark Mailing System Test - SUCCESS',
      html: testEmailTemplate
    };
    
    const info = await testTransporter.sendMail(testMailOptions);
    console.log('✅ Test email sent successfully!');
    console.log(`   Message ID: ${info.messageId}`);
    console.log(`   Sent to: ${info.accepted.join(', ')}\n`);
    
    console.log('🎉 Mailing system test completed successfully!');
    console.log('The system is ready to handle contact form submissions.\n');
    
  } catch (error) {
    console.error('❌ Test failed with error:', error.message);
    
    if (error.code === 'EAUTH') {
      console.log('\n🔐 Authentication Error:');
      console.log('   - Check your Gmail username and password');
      console.log('   - Ensure 2-Factor Authentication is enabled');
      console.log('   - Use App Password, not regular password');
      console.log('   - Verify .env file has correct credentials\n');
    } else if (error.code === 'ECONNECTION') {
      console.log('\n🌐 Connection Error:');
      console.log('   - Check your internet connection');
      console.log('   - Verify Gmail SMTP settings');
      console.log('   - Check firewall/antivirus settings\n');
    }
  }
}

// Run test if this file is executed directly
if (require.main === module) {
  testEmailSystem();
}

module.exports = { testEmailSystem };
